#include "Admin.h"

Admin::Admin(std::string id, std::string password) {
	this->id = id;
	this->password = password;
}