#include "Account.h"

std::string Account::getID() {
	return this->id;
}
std::string Account::getPassword() {
	return this->password;
}